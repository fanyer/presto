window.onload = function () {

    document.getElementById('saveButton').addEventListener('click', addEntry, false);

    if (opera.io.webserver)
    {
        opera.io.webserver.addEventListener('list', getEntryList, false);
        opera.io.webserver.addEventListener('entry', showEntry, false);
    }
}

var entries = [];

function addEntry(e)
{
    var titleField = document.getElementById('title');
    var textArea = document.getElementById('text');
    var title = titleField.value;
    entries.push({
        'title' : title, 
        'text'  : textArea.value,
        'date'  : new Date()
    });
    document.getElementById('message').textContent = 'Saved ' + title;
    titleField.value = '';
    textArea.textContent = '';
}

function getEntryList(e)
{
    var response = e.connection.response;
    response.write( '<!DOCTYPE html>'
        + '<html><head><title>Entries</title></head>'
        + '<body><ul>'
    );

    for ( var i = 0, entry; entry = entries[i]; i++ )
    {
        response.write('<li>'+entry.date+': <a href="entry?id='+i+'">'+entry.title+'</a></li>');
    }

    response.write('</ul></body></html>');
    response.close();
}

function showEntry(e)
{
    var index = e.connection.request.queryItems['id'][0];
    var entry = entries[index];
    var response = e.connection.response;
    response.write('<!DOCTYPE html>'
        + '<html><head><title>'+entry.title+'</title></head>'
        + '<body><h1>'+entry.title+'</h1>'
        + '<p>'+entry.date+'</p>'
        + '<div>'+entry.text+'</div>'
        + '</body></html>'
    );
    response.close();
}
